package com.modosmart.symbiote.modosmartsymbioteandroid.utils;

public class ConstantsUtil {
    public static final String FRAGMENT_ROOM_SENSOR_TAG = "RoomSensorFragment";
    public static final String FRAGMENT_AC_SWITCH_TAG = "AcSwitchFragment";
    public static final String FRAGMENT_SETTINGS_TAG = "SettingsFragment";

    public static final String SYMBIOTE_URL = "https://symbioteweb.eu.ngrok.io";
}
