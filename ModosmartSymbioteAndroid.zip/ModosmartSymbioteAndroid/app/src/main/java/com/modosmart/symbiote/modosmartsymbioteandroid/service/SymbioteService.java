package com.modosmart.symbiote.modosmartsymbioteandroid.service;

public class SymbioteService {
}
